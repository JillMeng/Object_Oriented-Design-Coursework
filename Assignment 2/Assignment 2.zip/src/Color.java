/**
 * This enum sets up a Color enum that contains two chess piece colors Black and White and make
 * them to the enum value.
 */
public enum Color { BLACK, WHITE
}
